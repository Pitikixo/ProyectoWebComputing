package main;

import java.sql.*;

import clases.*;
import server.Conexion;

public class Pruebas {
	
	//public static Connection connection;
	public static void main(String[] args) {
		
		
		//PRUEBA INSERTAR 3 VALORES EN TABLA-->MOSTRARLOS-->BORRARLOS-->MOSTRARLOS-----------------------------------------------------------
		/*try { 
			//Driver d= new org.postgresql.Driver();
			//DriverManager.registerDriver(d);
			//connection = DriverManager.getConnection("jdbc:postgresql://localhost/postgres","postgres","Zorrogris01");
		
			Conexion.initConnection();
			String queryINSERT = "insert into usuarios values('Pedro Hernandez', 'via genaro 18', 'piti@gmail.com', 'piti')";
			PreparedStatement statementINSERT = Conexion.getConnection().prepareStatement(queryINSERT);
			statementINSERT.executeUpdate();

			queryINSERT = "insert into usuarios values('Cindy Polanco', 'via genaro 19', 'cindy@gmail.com', 'cindy')";
			statementINSERT = Conexion.getConnection().prepareStatement(queryINSERT);
			statementINSERT.executeUpdate();

			queryINSERT = "insert into usuarios values('Marco Ita', 'via genaro 20', 'marco@gmail.com', 'marco')";
			statementINSERT = Conexion.getConnection().prepareStatement(queryINSERT);
			statementINSERT.executeUpdate();
			System.out.println("Insertados");
			
			String querySELECT = "select * from usuarios";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("nombre") + " ");
				System.out.print(result.getString("direccion") + " ");
				System.out.print(result.getString("email") + " ");
				System.out.println(result.getString("password") + " "); 
				System.out.println("----------------------------------------------------");
				
			}
			
			String queryDELETE = "delete from usuarios where email='piti@gmail.com'";
			PreparedStatement statementDELETE = Conexion.getConnection().prepareStatement(queryDELETE);
			statementDELETE.executeUpdate();

			queryDELETE = "delete from usuarios where email='cindy@gmail.com'";
			statementDELETE = Conexion.getConnection().prepareStatement(queryDELETE);
			statementDELETE.executeUpdate();

			queryDELETE = "delete from usuarios where email='marco@gmail.com'";
			statementDELETE = Conexion.getConnection().prepareStatement(queryDELETE);
			statementDELETE.executeUpdate();
			
			querySELECT = "select * from usuarios";
			statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			result = statementSELECT.executeQuery();
			System.out.println("Deleteados");
			
			while(result.next()) {
				System.out.print(result.getString("nombre") + " ");
				System.out.print(result.getString("direccion") + " ");
				System.out.print(result.getString("email") + " ");
				System.out.println(result.getString("password") + " "); 
				System.out.println("----------------------------------------------------");
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
		
		
		
		
		//PRUEBA CREAR 2 USUARIOS 1 LIBRO HACER UN PEIDDO UN INTERCAMBIO Y SEGUIR TODO EL PROCESO----------------------------------------------
		/*Conexion.initConnection();
		Usuario usuario1 = new Usuario("Piti", "via", "piti@gmail.com", "piti");
		Usuario usuario2 = new Usuario("Cindy", "viiia", "cindy@gmail.com", "cindy");
		Libro libro1 = new Libro("KK", "Culo", "AMOR", "189", usuario1);
	
		System.out.println("Lista de usuarios ------------------------");
	try {
		String querySELECT = "select * from usuarios";
		PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
		ResultSet result = statementSELECT.executeQuery();
		
		while(result.next()) {
			System.out.print(result.getString("nombre") + " ");
			System.out.print(result.getString("direccion") + " ");
			System.out.print(result.getString("email") + " ");
			System.out.println(result.getString("password") + " ");
			
		}
	} catch(SQLException e) {
		e.printStackTrace();
	}
		System.out.println("FIN lista de usuarios ------------------------");
		System.out.println("Lista de libros ------------------------");
	try {
		String querySELECT = "select * from libros";
		PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
		ResultSet result = statementSELECT.executeQuery();
		
		while(result.next()) {
			System.out.print(result.getString("titulo") + " ");
			System.out.print(result.getString("autor") + " ");
			System.out.print(result.getString("tipo") + " ");
			System.out.print(result.getString("isbn") + " ");
			System.out.println(result.getString("due�o") + " ");
			
		}
	} catch(SQLException e) {
		e.printStackTrace();
	}
		System.out.println("FIN lista de libros ------------------------");
		
		
		
		Pedido pedido1 = new Pedido(usuario2, usuario1, libro1);
		System.out.println("Lista de pedidos ------------------------");
		try {
			String querySELECT = "select * from pedidos";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("emisor") + " ");
				System.out.print(result.getString("receptor") + " ");
				System.out.println(result.getString("libro") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println("FIN lista de pedidos ------------------------");
		Intercambio intercambio1 = new Intercambio(pedido1, 10);
		System.out.println("Lista de pedidos ------------------------");
		try {
			String querySELECT = "select * from pedidos";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("emisor") + " ");
				System.out.print(result.getString("receptor") + " ");
				System.out.print(result.getString("libro") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println("FIN lista de pedidos ------------------------");
		System.out.println("Lista de intercambios ------------------------");
		try {
			String querySELECT = "select * from intercambios";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("due�o") + " ");
				System.out.print(result.getString("otro") + " ");
				System.out.print(result.getString("libro") + " ");
				System.out.println(result.getString("tempo") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println("FIN lista de intercambios ------------------------");
		usuario1.listarOfrecidos();
		System.out.println("Lista de libros ------------------------");
		try {
			String querySELECT = "select * from libros";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("titulo") + " ");
				System.out.print(result.getString("autor") + " ");
				System.out.print(result.getString("tipo") + " ");
				System.out.print(result.getString("isbn") + " ");
				System.out.println(result.getString("due�o") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
			System.out.println("FIN lista de libros ------------------------");*/
		
		
		
		
		//CREAR VARIOS INTERCAMBIOS Y COMPROBAR QUE ENTRAN/SALEN DE LA LISTA DE PEDIDOS E INTERCAMBIOS---------------------------------------
		/*Conexion.initConnection();
		Usuario usuario1 = new Usuario("Piti", "via", "piti@gmail.com", "piti");
		Usuario usuario2 = new Usuario("Cindy", "viiia", "cindy@gmail.com", "cindy");
		Libro libro1 = new Libro("K", "Culo", "AMOR", "1891", usuario1);
		Libro libro2 = new Libro("KK", "Culo", "AMOR", "1892", usuario1);
		Libro libro3 = new Libro("KKK", "Culo", "AMOR", "1893", usuario1);
		Libro libro4 = new Libro("KKKK", "Culo", "AMOR", "1894", usuario1);
		Pedido pedido1 = new Pedido(usuario2, usuario1, libro1);
		Pedido pedido2 = new Pedido(usuario2, usuario1, libro2);
		Pedido pedido3 = new Pedido(usuario2, usuario1, libro3);
		usuario1.listarOfrecidos();
		usuario1.listarPedidos();
		Intercambio intercambio1 = new Intercambio(pedido1, 5);
		Intercambio intercambio2 = new Intercambio(pedido2, 10);
		usuario1.listarOfrecidos();
		usuario1.listarPedidos();*/
		
		
		//PRUEBA DE CONEXION DE USUARIOS LOG_IN LOG_OFF-----------------------------------------------------------------------
		/*Conexion.initConnection();
		Usuario usuario1 = new Usuario("Piti", "via", "piti@gmail.com", "piti");
		Usuario usuario2 = new Usuario("Cindy", "viia", "cindy@gmail.com", "cindy");
		usuario1.conectarse();
		try {
			String querySELECT = "select * from conectados";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("usuario") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		usuario2.conectarse();
		try {
			String querySELECT = "select * from conectados";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("usuario") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		usuario1.desConectarse();
		try {
			String querySELECT = "select * from conectados";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("usuario") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}*/
		
		
		/*Conexion.initConnection();
		try {
			String querySELECT = "select count(*) from conectados";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("usuario") + " ");
				
			}
		} catch(SQLException e) {
			e.printStackTrace();
			System.out.println("tabla vacia");
	}*/
		//Pedido pedido = new Pedido("cindy@gmail.com", "piti@gmail.com", "KK", 5);
		//Pedido pedido = new Pedido("marco@gmail.com", "piti@gmail.com", "KK", 7);
	}

}
