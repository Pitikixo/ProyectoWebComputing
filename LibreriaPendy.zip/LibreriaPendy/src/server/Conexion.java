package server;

import java.sql.*;

public class Conexion {
	
	public static Connection connection; 
	
	public static void initConnection() {
		try {
			Driver d = new org.postgresql.Driver();
			DriverManager.registerDriver(d);
		//	connection = DriverManager.getConnection("jdbc:postgresql://192.168.43.240:5432/trillblitz","rhode","rhode");
			connection = DriverManager.getConnection("jdbc:postgresql://manny.db.elephantsql.com:5432/xsfemqro","xsfemqro","kTmeVOL0Sq-jc6D2sHpFSiB38yLvsxgW");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() { return connection; }
	
	public static void close() { try {
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}

}

	//SERVER: manny.db.elephantsql.com
	//USER: xsfemqro
	//PASSWORD: kTmeVOL0Sq-jc6D2sHpFSiB38yLvsxgW