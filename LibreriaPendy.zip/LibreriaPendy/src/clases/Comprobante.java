package clases;

import java.sql.*;
import server.Conexion;
import java.util.*;
public class Comprobante {
	public static ArrayList<Usuario> getUsuarios(){
		
		ArrayList<Usuario> gente = new ArrayList<>();
		Conexion.initConnection();
		try {
			String querySELECT = "select * from usuarios";
			PreparedStatement statementSELECT = Conexion.getConnection().prepareStatement(querySELECT);
			ResultSet result = statementSELECT.executeQuery();
			
			while(result.next()) {
				Usuario usuario = new Usuario();
	            usuario.setNombre(result.getString("nombre"));
	            usuario.setDireccion(result.getString("direccion"));
	            usuario.setEmail(result.getString("email"));
	            usuario.setPassword(result.getString("password"));
	            gente.add(usuario);
			}
            Conexion.close();
            statementSELECT.close();
			result.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return gente;
		
	}
}
