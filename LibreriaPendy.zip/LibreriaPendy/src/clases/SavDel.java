package clases;

public interface SavDel {
	
	public void save();
	public void delete();
}
