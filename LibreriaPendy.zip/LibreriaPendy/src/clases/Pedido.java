package clases;

import java.sql.*;

import server.Conexion;

public class Pedido implements SavDel{
	
	String emisor;//El que hace la pedido
	String receptor;//El que tiene el libro
	String libro;
	int tempo;
	
	public Pedido() {}
	
	public Pedido(String e, String r, String l, int t) {
		emisor = e;
		receptor = r;
		libro = l;
		tempo = t;
		System.out.println("Pedido de " + emisor + " a " + receptor + " por " + libro + "durante" + getTempo() + " realizado");
		this.save();
	}
	
	public String getEmisor() {return emisor;}
	public String getReceptor() {return receptor;}
	public String getLibro() {return libro;}
	public int getTempo() {return tempo;}
	
	public void setEmisor(String e) {emisor = e;}
	public void setReceptor(String r) {receptor = r;}
	public void setLibro(String l) {libro = l;}
	public void setTempo(int t) {tempo = t;}

	@Override
	public void save() {
		try {
			Conexion.initConnection();
			String insert = "insert into pedidos(emisor, receptor, libro, tempo) values (?,?,?,?)";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(insert);
			statement.setString(1, emisor);
			statement.setString(2, receptor);
			statement.setString(3, libro);
			statement.setInt(4, tempo);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();
		} catch(SQLException e){
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete() {
		try {
			Conexion.initConnection();
			String delete = "delete * from pedidos where emisor=? AND receptor=? AND libro=? AND tempo=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, emisor);
			statement.setString(2, receptor);
			statement.setString(3, libro);
			statement.setInt(4, tempo);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
}
