package clases;
import java.sql.*;
import java.util.*;

import server.Conexion;

public class Usuario implements SavDel{
	
	String nombre;
	String direccion;
	String email;
	String password;
	boolean logged = false;
	
	public Usuario() {}
	
	public Usuario(String n, String d, String e, String p) {
		nombre = n;
		direccion = d;
		email = e;
		password = p;
		System.out.println("Usuario " + nombre + " creado");
		this.save();
	}
	
	public String getNombre() { return nombre;}
	public String getDireccion() { return direccion;}
	public String getEmail() { return email;}
	public String getPassword() { return password;}
	
	public void setNombre(String n) { nombre = n;}
	public void setDireccion(String d) { direccion = d;}
	public void setEmail(String e) { email = e;}
	public void setPassword(String p) { password = p;}
	
	public void aceptarPedido(Pedido pe) {
		pe.delete();
		Intercambio intercambio = new Intercambio(pe);
		
		try {
			Conexion.initConnection();
			String delete = "update libros set libre='false' where due�o=? AND isbn=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, pe.receptor);
			statement.setString(2, pe.libro);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		try {
			Conexion.initConnection();
			String insert = "insert into intercambios(due�o,otro,libro) values (?,?,?)";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(insert);
			statement.setString(1, pe.receptor);
			statement.setString(2, pe.emisor);
			statement.setString(3, pe.libro);;
			statement.executeUpdate();

            Conexion.close();
            statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void rechazarPedido(Pedido pe) {
		pe.delete();
	}
	
	@Override
	public void save() {
		try {
			Conexion.initConnection();
			String insert = "insert into usuarios(nombre, direccion, email, password) values (?,?,?,?)";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(insert);
			statement.setString(1, nombre);
			statement.setString(2, direccion);
			statement.setString(3, email);
			statement.setString(4, password);
			statement.executeUpdate();
			

            Conexion.close();
            statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void delete() {
		try {
			Conexion.initConnection();
			String delete = "delete from usuarios where email=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, email);
			statement.executeUpdate();

            Conexion.close();
            statement.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void listarUsuarios() {
		try{
			Conexion.initConnection();
			String query = "select * from usuarios";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(query);
			ResultSet result = statement.executeQuery();
		
			while(result.next()) {
				System.out.print(result.getString("nombre") + " ");
				System.out.print(result.getString("direccion") + " ");
				System.out.print(result.getString("email") + " ");
				System.out.println(result.getString("password") + " "); 
				System.out.println("----------------------------------------------------");
			
		}

            Conexion.close();
            statement.close();
			result.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void listarOfrecidos() {
		try {
			Conexion.initConnection();
			String query = "select * from libros where due�o=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(query);
			statement.setString(1, email);
			ResultSet result = statement.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("titulo") + " ");
				System.out.print(result.getString("autor") + " ");
				System.out.println(result.getString("tipo") + " ");
				System.out.println(result.getString("isbn") + " ");
				System.out.println(result.getString("due�o") + " ");
			}

            Conexion.close();
            statement.close();
			result.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void listarPedidos() {
		System.out.println("Pedidos que el usuario " + this.nombre + " tiene pendientes: ");
		try {
			Conexion.initConnection();
			String query = "select * from pedidos where receptor=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(query);
			statement.setString(1, email);
			ResultSet result = statement.executeQuery();
			
			while(result.next()) {
				System.out.print(result.getString("emisor") + " ");
				System.out.print(result.getString("receptor") + " ");
				System.out.println(result.getString("libro") + " ");
				
			}

            Conexion.close();
            statement.close();
			result.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public String toString() {
		StringBuilder toret = new StringBuilder();
		toret.append("Nombre: ").append(this.nombre).append(" | Direccion: ").append(this.direccion)
		.append(" | Nom cuenta: ").append(this.email);
		return toret.toString();
	}
}
