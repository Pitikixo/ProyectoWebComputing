package clases;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import server.Conexion;

public class Libro implements SavDel{

	String titulo;
	String autor;
	/*enum Tipo { MISTERIO, FANTASIA, THRILLER, HISTORIA, AMOR, NULL}
	Tipo tipo;*/
	String tipo;
	String isbn;
	String due�o;
	boolean libre;
	
	
	public Libro() {}
	
	public Libro(String t, String a, String ti, /*Tipo ti,*/ String i, String d) {
		titulo = t;
		autor = a;
		tipo = ti;
		//tipo = ti;
		isbn = i;
		due�o = d;
		libre = true;
		System.out.println("Libro " + titulo + " creado");
		this.save();
	}
	
	public String getTitulo() { return titulo;}
	public String getAutor() { return autor;}
	public String getTipo() { return tipo;}
	public String getISBN() { return isbn;}
	public String getDue�o() { return due�o;}
	public boolean getLibre() { return libre;}
	
	public void setTitulo(String t) { titulo = t;}
	public void setAutor(String a) { autor = a;}
	public void setTipo(String ti) { tipo = ti;}
	public void setISBN(String isbn) { this.isbn = isbn;}
	public void setDue�o(String d) { due�o = d;}
	public void setLibre(boolean l) { libre = l;}
	
	@Override
	public void save() {
		try {
			Conexion.initConnection();
			String insert = "insert into libros(titulo, autor, tipo, isbn, due�o, libre) values (?,?,?,?,?,?)";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(insert);
			statement.setString(1, titulo);
			statement.setString(2, autor);
			statement.setString(3, tipo);
			statement.setString(4, isbn);
			statement.setString(5, due�o);
			statement.setBoolean(6, true);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void delete() {
		try {
			Conexion.initConnection();
			String delete = "update libros set libre='false' where due�o=? AND isbn=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, due�o);
			statement.setString(2, isbn);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		StringBuilder toret = new StringBuilder();
		toret.append("Titulo: ").append(this.titulo).append(" | autor: ").append(this.autor)
		.append(" | Tipo: ").append(this.tipo.toString()).append(" | ISBN: ").append(this.isbn)
		.append(" | Due�o: ").append(this.due�o);
		return toret.toString();
	}
}
