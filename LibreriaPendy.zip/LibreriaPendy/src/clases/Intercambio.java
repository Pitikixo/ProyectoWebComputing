package clases;

import java.sql.*;

import server.Conexion;

import clases.*;

public class Intercambio implements SavDel{
	
	String due�o;
	String otro;
	String libro;
	int tempo;
	
	public Intercambio() {}
	
	public Intercambio(Pedido p) {
		due�o = p.receptor;
		otro = p.emisor;
		libro = p.libro;
		tempo = p.tempo;
		System.out.println("Intercambio entre " + due�o + " y " + otro + " realizado");
		this.save();
	}
	
	public String getDue�o() {return due�o;}
	public String getOtro() {return otro;}
	public String getLibro() {return libro;}
	public int gettempo() {return tempo;}
	
	public void setDue�o(String d) {due�o = d;}
	public void setOtro(String o) {otro = o;}
	public void setLibro(String l) {libro = l;}
	public void settempo(int t) {tempo = t;}
	
	@Override
	public void save() {
		try {
			Conexion.initConnection();
			String insert = "insert into intercambios(due�o, otro, libro, tempo) values(?,?,?,?)";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(insert);
			statement.setString(1, due�o);
			statement.setString(2, otro);
			statement.setString(3, libro);
			statement.setInt(4, tempo);
			statement.executeUpdate();
			
			
			String delete = "delete from pedidos where emisor=? AND receptor=? AND libro=?";
			statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, otro);
			statement.setString(2, due�o);
			statement.setString(3, libro);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete() {
		try {
			Conexion.initConnection();
			String delete = "delete * from intercambios where due�o=? AND otro=? AND libro=? AND tempo=?";
			PreparedStatement statement = Conexion.getConnection().prepareStatement(delete);
			statement.setString(1, due�o);
			statement.setString(2, otro);
			statement.setString(3, libro);
			statement.setInt(4, tempo);
			statement.executeUpdate();
			
			Conexion.close();
            statement.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

}
